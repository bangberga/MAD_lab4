package com.example.mycity.data

enum class CategoryType {
    CoffeeShop, Restaurant, KidFriendlyPlace, Park, ShoppingCenter
}