package com.example.mycity.data

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Place (
    val id: Long,
    @StringRes val name: Int,
    @StringRes val about: Int,
    @StringRes val contactInfo : Int,
    val category: CategoryType,
    @DrawableRes val img: Int
)