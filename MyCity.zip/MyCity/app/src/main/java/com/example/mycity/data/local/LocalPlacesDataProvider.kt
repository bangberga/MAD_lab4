package com.example.mycity.data.local

import com.example.mycity.data.Place
import com.example.mycity.R
import com.example.mycity.data.CategoryType

object LocalPlacesDataProvider {

     val allPlaces = listOf(
        Place(
            id = 0L,
            name = R.string.place_0_name,
            about = R.string.place_0_about,
            contactInfo = R.string.place_0_contactInfo,
            img = R.drawable.place_0_img,
            category = CategoryType.CoffeeShop
        ),
        Place(
            id = 1L,
            name = R.string.place_1_name,
            about = R.string.place_1_about,
            contactInfo = R.string.place_1_contactInfo,
            img = R.drawable.place_1_img,
            category = CategoryType.CoffeeShop
        ),
        Place(
            id = 2L,
            name = R.string.place_2_name,
            about = R.string.place_2_about,
            contactInfo = R.string.place_2_contactInfo,
            img = R.drawable.place_2_img,
            category = CategoryType.CoffeeShop
        ),
        Place(
            id = 3L,
            name = R.string.place_3_name,
            about = R.string.place_3_about,
            contactInfo = R.string.place_3_contactInfo,
            img = R.drawable.place_3_img,
            category = CategoryType.Restaurant
        ),
        Place(
            id = 4L,
            name = R.string.place_4_name,
            about = R.string.place_4_about,
            contactInfo = R.string.place_4_contactInfo,
            img = R.drawable.place_4_img,
            category = CategoryType.Restaurant
        ),
        Place(
            id = 5L,
            name = R.string.place_5_name,
            about = R.string.place_5_about,
            contactInfo = R.string.place_5_contactInfo,
            img = R.drawable.place_5_img,
            category = CategoryType.Restaurant
        ),
        Place(
            id = 6L,
            name = R.string.place_6_name,
            about = R.string.place_6_about,
            contactInfo = R.string.place_6_contactInfo,
            img = R.drawable.place_6_img,
            category = CategoryType.KidFriendlyPlace
        ),
        Place(
            id = 7L,
            name = R.string.place_7_name,
            about = R.string.place_7_about,
            contactInfo = R.string.place_7_contactInfo,
            img = R.drawable.place_7_img,
            category = CategoryType.Park
        ),
        Place(
            id = 8L,
            name = R.string.place_8_name,
            about = R.string.place_8_about,
            contactInfo = R.string.place_8_contactInfo,
            img = R.drawable.place_8_img,
            category = CategoryType.Park
        ),
        Place(
            id = 9L,
            name = R.string.place_9_name,
            about = R.string.place_9_about,
            contactInfo = R.string.place_9_contactInfo,
            img = R.drawable.place_9_img,
            category = CategoryType.ShoppingCenter
        )
    )

    /**
     * Get an [Place] with the given [id].
     */
    fun get(id: Long): Place? {
        return allPlaces.firstOrNull { it.id == id }
    }

    val defaultPlace = Place(
        id = -1,
        name = -1,
        about = -1,
        contactInfo = -1,
        img = R.drawable.place_0_img,
        category = CategoryType.CoffeeShop
    )
}