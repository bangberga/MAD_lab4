package com.example.mycity.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.example.mycity.R
import com.example.mycity.data.Place
import com.example.mycity.ui.utils.MyCityContentType


@Composable
fun MyCityDetailsScreen(
    currentSelectedPlace: Place,
    contentType: MyCityContentType,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    onBackPressed: () -> Unit,
    modifier: Modifier = Modifier
){
    print(stringResource(currentSelectedPlace.contactInfo).toString())
    BackHandler {
        onBackPressed()
    }
    val scrollState = rememberScrollState()
    val layoutDirection = LocalLayoutDirection.current
    Box(
        modifier = modifier
            .verticalScroll(state = scrollState)
            .padding(top = contentPadding.calculateTopPadding())
    ) {
        Column(
            modifier = Modifier
                .padding(
                    bottom = contentPadding.calculateTopPadding(),
                    start = contentPadding.calculateStartPadding(layoutDirection),
                    end = contentPadding.calculateEndPadding(layoutDirection)
                )
        ) {
            AnimatedVisibility(visible = contentType == MyCityContentType.Category_And_Places){
                MyCityDetailsTopBar(
                    onBackPressed = onBackPressed,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = dimensionResource(R.dimen.detail_topbar_padding_bottom))
                )
            }
            Image(
                painter = painterResource(currentSelectedPlace.img),
                contentDescription = null,
                alignment = Alignment.Center,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(
                        dimensionResource(id = R.dimen.detail_image_height)
                    )
                    .padding(
                        bottom = dimensionResource(id = R.dimen.padding_medium)
                    )
            )
            Text(
                text = stringResource(currentSelectedPlace.name),
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier
                    .padding(horizontal = dimensionResource(R.dimen.padding_small))
            )
            Text(
                text = stringResource(currentSelectedPlace.about),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(
                    vertical = dimensionResource(R.dimen.padding_detail_content_vertical),
                )
            )
            FormattedContactInfoText(
                currentSelectedPlace = currentSelectedPlace,
                modifier = Modifier.padding(
                    vertical = dimensionResource(R.dimen.padding_detail_content_vertical),
                )
            )
        }
    }
}

@Composable
fun MyCityDetailsTopBar(
    onBackPressed: () -> Unit,
    modifier: Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(
            onClick = onBackPressed,
            modifier = Modifier
                .padding(horizontal = dimensionResource(R.dimen.detail_topbar_back_button_padding_horizontal))
                .background(MaterialTheme.colorScheme.surface, shape = CircleShape),
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = stringResource(id = R.string.navigation_back)
            )
        }
        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(end = dimensionResource(R.dimen.detail_subject_padding_end))
        ) {
            Text(
                text = stringResource(R.string.detail_fragment_label),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun FormattedContactInfoText(
    currentSelectedPlace: Place,
    modifier: Modifier = Modifier
){
    val originalText = stringResource(currentSelectedPlace.contactInfo)
    val formattedText = buildAnnotatedString {
        originalText.split("\n\n").forEachIndexed { index, paragraph ->
            paragraph.split('\n').forEachIndexed { lineIndex, line ->
                if (lineIndex == 0) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append("•   ")
                    }
                }
                append(line)
                if (lineIndex < paragraph.split('\n').size - 1) {
                    append("\n")
                }
            }
            if (index < originalText.split("\n\n").size - 1) {
                append("\n\n")
            }
        }
    }

    Text(
        text = formattedText,
        style = MaterialTheme.typography.bodyMedium,
        modifier = modifier
    )
}
