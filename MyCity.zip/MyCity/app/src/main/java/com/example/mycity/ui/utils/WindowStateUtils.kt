package com.example.mycity.ui.utils

import androidx.annotation.StringRes
import com.example.mycity.R

enum class CurrentScreen(@StringRes val title: Int) {
    Home(title = R.string.home_fragment_label),
    Places(title = R.string.places_fragment_label),
    Detail(title = R.string.detail_fragment_label)
}

enum class MyCityContentType{
    Category_Only, Category_And_Places
}