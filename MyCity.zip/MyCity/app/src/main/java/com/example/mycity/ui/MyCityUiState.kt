package com.example.mycity.ui

import com.example.mycity.data.CategoryType
import com.example.mycity.data.Place
import com.example.mycity.data.local.LocalPlacesDataProvider
import com.example.mycity.ui.utils.CurrentScreen


data class MyCityUiState(
    val categories: Map<CategoryType, List<Place>> = emptyMap(),
    val currentSelectedCategory: CategoryType = CategoryType.CoffeeShop,
    val currentSelectedPlace: Place = LocalPlacesDataProvider.defaultPlace,
    val currentScreen: CurrentScreen = CurrentScreen.Home
) {
    val currentCategoryPlaces: List<Place> by lazy { categories[currentSelectedCategory]!! }
}
