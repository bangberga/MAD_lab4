package com.example.mycity.ui

import androidx.lifecycle.ViewModel
import com.example.mycity.data.CategoryType
import com.example.mycity.data.Place
import com.example.mycity.data.local.LocalPlacesDataProvider
import com.example.mycity.ui.utils.CurrentScreen
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class MyCityViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(MyCityUiState())
    val uiState: StateFlow<MyCityUiState> = _uiState

    init {
        initializeUIState()
    }

    private fun initializeUIState() {
        val categories: Map<CategoryType, List<Place>> =
            LocalPlacesDataProvider.allPlaces.groupBy { it.category }
        _uiState.value =
            MyCityUiState(
                categories = categories,
                currentSelectedPlace = categories[CategoryType.CoffeeShop]?.get(0)
                    ?: LocalPlacesDataProvider.defaultPlace
            )
    }

    fun updateCurrentScreen(currentScreen: CurrentScreen) {
        _uiState.update {
            it.copy(
                currentScreen = currentScreen
            )
        }
    }

    fun resetCurrentScreenStates() {
        _uiState.update {
            when(it.currentScreen) {
                CurrentScreen.Places -> it.copy(
                    currentScreen = CurrentScreen.Home,
                    currentSelectedCategory = CategoryType.CoffeeShop
                )
                CurrentScreen.Detail -> it.copy(
                    currentScreen = CurrentScreen.Places,
                    currentSelectedPlace = it.categories[it.currentSelectedCategory]?.get(0)
                        ?: LocalPlacesDataProvider.defaultPlace,
                )
                else -> it
            }
        }
    }

    fun updateCurrentSelectedCategory(categoryType: CategoryType) {
        _uiState.update {
            it.copy(
                currentSelectedCategory = categoryType
            )
        }
    }

    fun updateCurrentSelectedPlace(place : Place) {
        _uiState.update {
            it.copy(
                currentSelectedPlace = place
            )
        }
    }

}