package com.example.mycity.ui

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.mycity.R
import com.example.mycity.data.CategoryType
import com.example.mycity.data.Place
import com.example.mycity.ui.utils.CurrentScreen
import com.example.mycity.ui.utils.MyCityContentType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyCityHomeScreen(
    myCityUiState: MyCityUiState,
    contentType: MyCityContentType,
    onCategoryCardClick: (CategoryType) -> Unit,
    onPlaceCardClick: (Place) -> Unit,
    onBackPressed: () -> Unit,
    modifier: Modifier = Modifier
){
    val categoryItemContentList = listOf(
        CategoryItemContent(
            id = 1L,
            categoryType = CategoryType.CoffeeShop,
            text = stringResource(id = R.string.tab_coffee_shop)
        ),
        CategoryItemContent(
            id = 2L,
            categoryType = CategoryType.Restaurant,
            text = stringResource(id = R.string.tab_restaurant)
        ),
        CategoryItemContent(
            id = 3L,
            categoryType = CategoryType.KidFriendlyPlace,
            text = stringResource(id = R.string.tab_kid_friendly_place)
        ),
        CategoryItemContent(
            id = 4L,
            categoryType = CategoryType.Park,
            text = stringResource(id = R.string.tab_park)
        ),
        CategoryItemContent(
            id = 5L,
            categoryType = CategoryType.ShoppingCenter,
            text = stringResource(id = R.string.tab_shopping_center)
        )
    )
    Scaffold(
        topBar = {
            MyCityAppBar(
                contentType = contentType,
                currentScreen = myCityUiState.currentScreen,
                onBackButtonClick = onBackPressed
            )
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .padding(
                    all = dimensionResource(id = R.dimen.padding_medium)
                )
        ){
            if(contentType == MyCityContentType.Category_Only){
                when (myCityUiState.currentScreen) {
                    CurrentScreen.Home -> {
                        MyCityCategoriesScreen(
                            contentType = contentType,
                            categoryItemContentList = categoryItemContentList,
                            onCategoryCardClick = onCategoryCardClick,
                            contentPadding = innerPadding,
                            currentSelectedCategory = myCityUiState.currentSelectedCategory,
                            modifier = modifier
                        )
                    }
                    CurrentScreen.Places -> {
                        MyCityPlacesScreen(
                            currentCategoryPlaces = myCityUiState.currentCategoryPlaces,
                            contentPadding = innerPadding,
                            onPlaceCardClick = onPlaceCardClick,
                            onBackPressed = onBackPressed,
                            modifier = modifier
                        )
                    }
                    else -> {
                        MyCityDetailsScreen(
                            contentType = contentType,
                            currentSelectedPlace = myCityUiState.currentSelectedPlace,
                            contentPadding = innerPadding,
                            onBackPressed = onBackPressed,
                            modifier = modifier
                        )
                    }
                }
            } else {
                MyCityCategoryAndPlacesOrDetailsScreen(
                    contentType = contentType,
                    currentSelectedPlace = myCityUiState.currentSelectedPlace,
                    currentSelectedCategory = myCityUiState.currentSelectedCategory,
                    currentScreen = myCityUiState.currentScreen,
                    categoryItemContentList = categoryItemContentList,
                    onCategoryCardClick = onCategoryCardClick,
                    currentCategoryPlaces = myCityUiState.currentCategoryPlaces,
                    onPlaceCardClick = onPlaceCardClick,
                    onBackPressed = onBackPressed,
                    modifier = modifier
                )
            }
        }
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyCityAppBar(
    contentType: MyCityContentType,
    onBackButtonClick: () -> Unit,
    currentScreen: CurrentScreen,
    modifier: Modifier = Modifier
) {
    if(contentType == MyCityContentType.Category_Only) {
        TopAppBar(
            title = { Text(stringResource(id = currentScreen.title), color = MaterialTheme.colorScheme.scrim) },
            navigationIcon = if (currentScreen != CurrentScreen.Home) {
                {
                    IconButton(onClick = onBackButtonClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back_button),
                            tint = MaterialTheme.colorScheme.scrim
                        )
                    }
                }
            } else {
                { Box {} }
            },
            colors = TopAppBarDefaults.mediumTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.surfaceTint
            ),
            modifier = modifier,
        )
    }
}

@Composable
fun MyCityCategoriesScreen(
    contentType: MyCityContentType,
    currentSelectedCategory: CategoryType,
    categoryItemContentList: List<CategoryItemContent>,
    onCategoryCardClick: (CategoryType) -> Unit,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    modifier: Modifier = Modifier
){
    LazyColumn(
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_medium)),
        modifier = modifier
    ) {
        items(categoryItemContentList, key = {category -> category.id}) { category ->
            MyCityCategoryListItem(
                contentType = contentType,
                categoryItem = category,
                selected = category.categoryType == currentSelectedCategory,
                onCategoryCardClick = onCategoryCardClick
            )
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyCityCategoryListItem(
    contentType: MyCityContentType,
    categoryItem: CategoryItemContent,
    selected: Boolean,
    onCategoryCardClick: (CategoryType) -> Unit,
    modifier: Modifier = Modifier
){
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (selected && contentType != MyCityContentType.Category_Only)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.secondaryContainer
        ),
        onClick = {
            onCategoryCardClick(categoryItem.categoryType)
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(dimensionResource(R.dimen.category_list_item_inner_padding))
        ) {
            Text(
                text = categoryItem.text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
fun MyCityCategoryAndPlacesOrDetailsScreen(
    contentType: MyCityContentType,
    currentScreen: CurrentScreen,
    currentSelectedPlace: Place,
    currentSelectedCategory: CategoryType,
    categoryItemContentList: List<CategoryItemContent>,
    onCategoryCardClick: (CategoryType) -> Unit,
    currentCategoryPlaces: List<Place>,
    onPlaceCardClick: (Place) -> Unit,
    onBackPressed: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(modifier = modifier) {
        MyCityCategoriesScreen(
            contentType = contentType,
            currentSelectedCategory = currentSelectedCategory,
            categoryItemContentList = categoryItemContentList,
            onCategoryCardClick = onCategoryCardClick,
            modifier = Modifier
                .weight(2f)
                .padding(horizontal = dimensionResource(R.dimen.padding_medium))
        )
        val activity = LocalContext.current as Activity
        Box(modifier = Modifier.weight(3f)){
            if (currentScreen == CurrentScreen.Detail){
                MyCityDetailsScreen(
                    contentType = contentType,
                    currentSelectedPlace = currentSelectedPlace,
                    onBackPressed = onBackPressed
                )
            } else {
                MyCityPlacesScreen(
                    currentCategoryPlaces = currentCategoryPlaces,
                    onPlaceCardClick = onPlaceCardClick,
                    onBackPressed = { activity.finish() },
                )
            }
        }
    }
}

data class CategoryItemContent(
    val id: Long,
    val categoryType: CategoryType,
    val text: String
)